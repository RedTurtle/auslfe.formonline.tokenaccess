
from zope.i18nmessageid import MessageFactory
messageFactory = MessageFactory('auslfe.formonline.tokenaccess')

def initialize(context):
    """Initializer called when used as a Zope 2 product."""
